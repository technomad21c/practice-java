package com.masimo.vendingmachine;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import org.junit.*;

public class MasimoVendingMachineTest {
	private VendingMachine vm;
	
	@Before
	public void create() {
		vm = VendingMachineFactory.getVendingMachine("masimo", "Masimo Vending Machine", "20200317", "123 Norwood Ave, Vencouver", 100, "Brandon Jeong");
	}

	@Test
	public void RunningTotalIncreaseWhenCoinInserted() {			
		Coin coin = Coin.QUARTER;
		vm.insertCoin(coin);
		coin = Coin.DIME;
		vm.insertCoin(coin);
		
		assertThat(vm.getRunningTotal(), is(35));
		
		coin = Coin.NICKEL;
		vm.insertCoin(coin);
		
		assertThat(vm.getRunningTotal(), is(40));
	}
	
	@Test
	public void RunningTotalNotExceedMaxFund() {
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.DIME);
		vm.insertCoin(Coin.NICKEL);
		
		assertThat(vm.getRunningTotal(), is(100));
	}
	
	@Test
	public void RunningTotalDecreaseWhenItemDispensed() {			
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.QUARTER);
		Item item = vm.getItems().get(0);
		vm.selectItem(item);
		
		assertThat(vm.getRunningTotal(), is(20));
		
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.QUARTER);
		item = vm.getItems().get(1);		
		vm.selectItem(item);
		
		assertThat(vm.getRunningTotal(), is(0));
		
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.DIME);
		vm.insertCoin(Coin.NICKEL);
		item = vm.getItems().get(2);		
		vm.selectItem(item);
		
		assertThat(vm.getRunningTotal(), is(15));
	}
	
	@Test
	public void ItemDispensedWhenFundSufficient() {
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.QUARTER);			
		Item item = vm.getItems().get(0);
		
		assertThat(vm.selectItem(item), is(ResponseStatus.SUCCESS_ITEM_DISPENSE));
		assertThat(vm.getRunningTotal(), is(20));
		
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.DIME);		
		item = vm.getItems().get(1);
		
		assertThat(vm.selectItem(item), is(ResponseStatus.SUCCESS_ITEM_DISPENSE));
		assertThat(vm.getRunningTotal(), is(10));
		
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.QUARTER);		
		vm.insertCoin(Coin.NICKEL);				
		item = vm.getItems().get(2);
		
		assertThat(vm.selectItem(item), is(ResponseStatus.SUCCESS_ITEM_DISPENSE));
		assertThat(vm.getRunningTotal(), is(15));
	}
	
	@Test
	public void ItemNotDispensedWhenFundInsufficient() {
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.QUARTER);
		Item item = vm.getItems().get(0);
		int currentInventory = item.getInventory();		
		
		assertThat(vm.selectItem(item), is(ResponseStatus.FAILURE_INSUFFICIENT_FUND_RETURN_COIN));
		assertThat(vm.getItems().get(0).getInventory(), is(currentInventory));
		
		item = vm.getItems().get(1);
		currentInventory = item.getInventory();
				
		assertThat(vm.selectItem(item), is(ResponseStatus.FAILURE_INSUFFICIENT_FUND_RETURN_COIN));
		assertThat(vm.getItems().get(1).getInventory(), is(currentInventory));
		
		item = vm.getItems().get(2);
		currentInventory = item.getInventory();		
		
		assertThat(vm.selectItem(item), is(ResponseStatus.FAILURE_INSUFFICIENT_FUND_RETURN_COIN));
		assertThat(vm.getItems().get(2).getInventory(), is(currentInventory));
	}
	
	@Test
	public void VendingMachineResetWhenCoinReturend() {
		vm.insertCoin(Coin.QUARTER);
		vm.insertCoin(Coin.QUARTER);
		vm.returnCoin();
		
		assertThat(vm.getRunningTotal(), is(0));
		assertThat(vm.getItems().get(0).getInventory(), is(10));
		assertThat(vm.getItems().get(1).getInventory(), is(10));
		assertThat(vm.getItems().get(2).getInventory(), is(10));
	}
}

