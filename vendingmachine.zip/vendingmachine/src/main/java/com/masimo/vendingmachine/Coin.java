package com.masimo.vendingmachine;

public enum Coin {
	NICKEL("Nickel", 5),
	DIME("Dime", 10),
	QUARTER("Quarter", 25);  
	
	private String coinName;
	private int coinWorth;
	
	Coin(final String coinString, final int coinWorth) {
		this.coinName = coinString;
		this.coinWorth  = coinWorth;
	}
	
	public String getCoinString() {
		return coinName;
	}
	
	public int getCoinWorth() {
		return coinWorth;
	}	
}
