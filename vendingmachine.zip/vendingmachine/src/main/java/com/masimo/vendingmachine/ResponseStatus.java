package com.masimo.vendingmachine;

public enum ResponseStatus {
	WAITING                                   ("100", "Waiting for Customer             "),
	
	SUCCESS                                   ("200", "Sucess                           "),
	SUCCESS_COIN_INSERTION                    ("210", "Sucessfully inserted a coin      "),
	SUCCESS_ITEM_DISPENSE                     ("220", "Sucessfully dispensed the item   "),
	SUCCESS_COIN_RETURN                       ("230", "return all coins inserted        "),
	SUCCESS_RESET                             ("240", "return balance, reset the machine"),
	
	FAILURE                                   ("500", "Failed"),	
	FAILURE_RETURN_COIN                       ("510", "Coins return failed              "),
	FAILURE_EXCEEDING_MAX_FUND                ("520", "The fund is limited to 100 cents "),
	FAILURE_INSUFFICIENT_FUND_RETURN_COIN     ("530", "Balance insufficient,Coins return"),
	FAILURE_INSUFFICIENT_INVENTORY            ("540", "Inventory of Item is insufficient");
		
	private String code;
	private String message;
	
	private ResponseStatus(final String code, final String message) {
		this.code = code;
		this.message = message;
	}
	
	public String getCode() {
		return code;
	}
	
	public String getMessage() {
		return message;
	}
	
	
}
