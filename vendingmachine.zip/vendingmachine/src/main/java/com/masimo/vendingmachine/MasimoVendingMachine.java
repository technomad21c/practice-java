package com.masimo.vendingmachine;

import java.util.ArrayList;
import java.util.List;

public class MasimoVendingMachine extends VendingMachine {

	private String name;
	private String vmId;
	private String addr;
	private String manager;
	private int runningTotal;
	private int maxFund;
	private List<Item> items;
	public static final int DEFAULT_INVENTORY = 10;
	private boolean dispenseStatus;
	
	public MasimoVendingMachine(String name, String vmId, String addr, String manager, int maxFund, List<Item> items) {
		this.name = name;
		this.vmId = vmId;
		this.addr = addr;		
		this.manager = manager;
		this.runningTotal = 0;
		this.maxFund = maxFund;
		this.items = items;				
		this.dispenseStatus = false;		
	}
	
	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String getName() {
		return name;
	}
	
	public void setVmId(String vmId) {
		this.vmId = vmId;
	}
	
	public String getVmId() {
		return vmId;
	}
	
	public void setAddr(String addr) {
		this.addr = addr;
	}
	
	public String getAddr() {
		return addr;
	}	
	
	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}
	
	@Override
	public void setItems(List<Item> items) {		
		this.items = items;
	}
	
	@Override
	public void addItems(Item item) {		
		items.add(item);
	}

	@Override
	public List<Item> getItems() {
		return items;
	}

	@Override
	public ResponseStatus insertCoin(Coin coin) {
		int newTotal = runningTotal + coin.getCoinWorth();
		if (newTotal <= getMaxFund()) { 
			runningTotal = newTotal;
			return ResponseStatus.SUCCESS_COIN_INSERTION;
		} else {
			return ResponseStatus.FAILURE_EXCEEDING_MAX_FUND;
		}
	}
	
	@Override
	public ResponseStatus selectItem(Item item) {
		if (runningTotal < item.getPrice()) {
			dispenseStatus = false;
			returnCoin();
			return ResponseStatus.FAILURE_INSUFFICIENT_FUND_RETURN_COIN;
		} else if (item.getInventory() <= 0) {
			dispenseStatus = false;
			return ResponseStatus.FAILURE_INSUFFICIENT_INVENTORY;
		} else {				
			dispenseStatus = true;
			runningTotal -= item.getPrice();
			item.setInventory(item.getInventory() - 1);
			
			return ResponseStatus.SUCCESS_ITEM_DISPENSE;		
		}
	}

	public void setRunningTotal(int runningTotal) {
		this.runningTotal = runningTotal;
	}
	
	@Override
	public int getRunningTotal() { 
		return runningTotal;
	}

	@Override
	public int getMaxFund() {
		return maxFund;
	}
	
	public void setMaxFund(int maxFund) {
		this.maxFund = maxFund;
	}

	@Override
	public boolean getDispenseStatus() {		
		return dispenseStatus;
	}
		
	public void setDispenseStatus(boolean status) {		
		this.dispenseStatus = status;;
	}

	@Override
	public ResponseStatus returnCoin() {
		runningTotal = 0;
		return ResponseStatus.SUCCESS_COIN_RETURN;
	}

	@Override
	public ResponseStatus reset() {		
		runningTotal = 0;
		List<Item> resetItems = new ArrayList<Item>();
		for (Item i : items) {
			resetItems.add( new Item
					.Builder(i.getName(), i.getPrice())
					.inventory(MasimoVendingMachine.DEFAULT_INVENTORY)
					.build() );			
		}
		setItems(resetItems);
		setDispenseStatus(false);
		
		return ResponseStatus.SUCCESS_RESET;		
	}

}
