package com.masimo.vendingmachine;

import java.io.IOException;
import java.util.Optional;
import java.util.Scanner;

public class App 
{
    public static void main( String[] args ) throws InterruptedException, IOException 
    {
    	VendingMachine vm = VendingMachineFactory.getVendingMachine("masimo", "Masimo Vending Machine", "20200316", "123 Norwood Ave, Vencouver", 100, "John Doe");
    	ResponseStatus res = ResponseStatus.WAITING;
    	
    	Scanner scanner = new Scanner(System.in);    	
    	char inputKey = ' ';
    	String centSign = "\u00A2";
    	boolean quit = false;
    	Item selectedItem = new Item
    			.Builder("Item  ", 0)
    			.build();
    	do {  
    		new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor(); 
    		System.out.printf("\t\t            ***** %s *****\n", vm.getName());    		
    		System.out.printf("\t\t -----------------------------------------------------------\n");
    		System.out.printf("\t\t|                                                           |\n");
    		System.out.printf("\t\t|  + Display -----------------------------------------------|\n");
    		System.out.printf("\t\t|      Balance : %s%3d (Max: %s%d)                           |\n", centSign, vm.getRunningTotal(),centSign, vm.getMaxFund());
    		System.out.printf("\t\t|      Dispense: %s %s                       |\n", selectedItem.getName(), vm.getDispenseStatus()? "dispensed    " : "not dispensed"); 
    		System.out.printf("\t\t|      Status  : %s          |\n", res.getMessage());
    		System.out.printf("\t\t|                                                           |\n");
    		System.out.printf("\t\t|                                                           |\n");    		
    		System.out.printf("\t\t|  + Inventory Items ---------------------------------------|\n");
    		System.out.printf("\t\t|      Item      Price     Inventory     How To Buy         |\n");    		
    		int keyNo = 1;
    		for (Item i : vm.getItems()) {
    			System.out.printf("\t\t|     %s      %s%d         %2d           type \'%d\'         |\n", i.getName(), centSign, i.getPrice(), i.getInventory(), keyNo++);    			
    		}    		
    		System.out.printf("\t\t|                                                           |\n");
    		System.out.printf("\t\t|                                                           |\n");
    		System.out.printf("\t\t|  + Acceptable Coins --------------------------------------|\n");
    		System.out.printf("\t\t|        Coin Type        How To Insert                     |\n", centSign);
    		System.out.printf("\t\t|     Nickel (%s5 )        type 'n'                          |\n", centSign);
    		System.out.printf("\t\t|     Dime   (%s10)        type 'd'                          |\n", centSign);
    		System.out.printf("\t\t|     Quarter(%s25)        type 'q'                          |\n", centSign);    		
    		System.out.printf("\t\t|                                                           |\n");
    		System.out.printf("\t\t|                                                           |\n");
    		System.out.printf("\t\t|-----------------------------------------------------------|\n");
    		System.out.printf("\t\t|                                                           |\n");
    		System.out.printf("\t\t|  + type 'r' to return inserted coins                      |\n");
    		System.out.printf("\t\t|  + type 'x' to exit                                       |\n");
    		System.out.printf("\t\t|                                                           |\n");
    		System.out.printf("\t\t -----------------------------------------------------------\n\n");    		
    		System.out.printf("\t\tpress type the key to get an item or insert a coin:      \n\t\t");
    		inputKey = scanner.next().charAt(0);
    		
    		switch (Character.isDigit(inputKey) ? '0' : inputKey) {
    			case '0':
    				selectedItem = vm.getItems().get(Character.getNumericValue(inputKey)-1);
    				res = vm.selectItem(selectedItem);
    				break;
    			case 'n':
    				res = vm.insertCoin(Coin.NICKEL);
    				break;
    			case 'd':
    				res = vm.insertCoin(Coin.DIME);
    				break;    				
    			case 'q':
    				res = vm.insertCoin(Coin.QUARTER);
    				break;
    			case 'r':
    				vm.returnCoin();
    				res = vm.reset();
    				selectedItem = new Item
    		    			.Builder("Item  ", 0)
    		    			.build();
    				break;
    			case 'x':
    				quit = true;
    				break;
    			default:
    				break;    				
    		}
    		  		
    	} while (quit == false);
    	
    	System.exit(0);
    }
}
