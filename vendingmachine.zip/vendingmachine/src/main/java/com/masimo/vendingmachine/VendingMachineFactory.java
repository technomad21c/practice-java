package com.masimo.vendingmachine;

import java.util.ArrayList;
import java.util.List;

public class VendingMachineFactory {
	public static VendingMachine getVendingMachine(String type, String name, String vmId, String addr, int maxFund, String manager) {
		if ("masimo".equals(type)) {
			// initialize items for masimo vending machine
			List<Item> items = new ArrayList<Item>();
			items.add( new Item
					.Builder("Item 1", 55)
					.inventory(MasimoVendingMachine.DEFAULT_INVENTORY)
					.build() );
			items.add( new Item
					.Builder("Item 2", 70)
					.inventory(MasimoVendingMachine.DEFAULT_INVENTORY)
					.build() );
			items.add( new Item
					.Builder("Item 3", 75)
					.inventory(MasimoVendingMachine.DEFAULT_INVENTORY)
					.build() );
			
			return new MasimoVendingMachine(name, vmId, addr, manager, maxFund, items);			
		}
		
// can extend to implement another type vending machine later		
//		else if ("coffee".equals(type)) {
//			// initialize items for coffee vending machine
//			List<Item> items = new ArrayList<Item>();
//			items.add( new Item
//					.Builder("Black", 70)
//					.inventory(CoffeeVendingMachine.DEFAULT_INVENTORY)
//					.build() );
//			items.add( new Item
//					.Builder("Latte", 80)
//					.inventory(CoffeeVendingMachine.DEFAULT_INVENTORY)
//					.build() );
//			items.add( new Item
//					.Builder("Capuccino", 90)
//					.inventory(CoffeeVendingMachine.DEFAULT_INVENTORY)
//					.build() );
//			
//			return new CoffeeVendingMachine(name, vmId, addr, manager, items);
//		}
		
		return null;
	}
}
