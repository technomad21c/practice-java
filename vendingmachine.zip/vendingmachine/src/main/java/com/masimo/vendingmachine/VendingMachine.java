package com.masimo.vendingmachine;

import java.util.List;

public abstract class VendingMachine {	
	public abstract void setName(String name);
	public abstract String getName();
	public abstract void setItems(List<Item> items);
	public abstract void addItems(Item item);
	public abstract List<Item> getItems();	
	public abstract ResponseStatus insertCoin(Coin coin);
	public abstract ResponseStatus selectItem(Item item);	
	public abstract int getRunningTotal();
	public abstract int getMaxFund();
	public abstract boolean getDispenseStatus();	
	public abstract ResponseStatus returnCoin();
	public abstract ResponseStatus reset();	
	
	@Override
	public String toString() {
		return "Vending Machine's Name: " + getName();
	}
}
