package com.masimo.vendingmachine;

public class Item {
	private String name;
	private int price;
	private int inventory;
	
	// getter
	public String getName() {
		return name;
	}

	public int getPrice() {
		return price;
	}

	public int getInventory() {
		return inventory;
	}
	
	// setter
	public void setInventory(int inventory) {
		this.inventory = inventory;
	}
	
	public void addInventory(int inventory) {
		this.inventory += inventory;
	}

	public static class Builder {
		// mandatory
		private String name;
		private int price;
		
		// optional
		private int inventory;
		
		public Builder(String name, int price) {
			this.name = name;
			this.price = price;			
		}
		
		public Builder inventory(int val) {
			inventory = val;
			return this;
		}		
		public Item build() {
			return new Item(this);
		}
	}

	private Item(Builder builder) {
		name = builder.name;
		price = builder.price;
		inventory = builder.inventory;
	}
}
